import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Signup implements ActionListener {
    JFrame frame = new JFrame("Sign Up");
    JTextField nameField = new JTextField(20);
    JTextField addressField = new JTextField(20);
    JTextField ageField = new JTextField(20);
    JTextField phoneField = new JTextField(20);
    JTextField emailField = new JTextField(20);
    JTextField userIDField = new JTextField(20);
    JPasswordField passwordField = new JPasswordField(20);
    JCheckBox terms = new JCheckBox("I agree to the Terms and Conditions");
    JButton submitButton = new JButton("Submit");
    JLabel messageLabel = new JLabel();

    IDandPasswords idandPasswords;

    public Signup(IDandPasswords idandPasswords) {
        this.idandPasswords = idandPasswords;

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        addFormField(mainPanel, gbc, "Name:", nameField, 0);
        addFormField(mainPanel, gbc, "Address:", addressField, 1);
        addFormField(mainPanel, gbc, "Age:", ageField, 2);
        addFormField(mainPanel, gbc, "Phone:", phoneField, 3);
        addFormField(mainPanel, gbc, "Email:", emailField, 4);
        addFormField(mainPanel, gbc, "Username:", userIDField, 5);
        addFormField(mainPanel, gbc, "Password:", passwordField, 6);

        gbc.gridy = 7;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        mainPanel.add(terms, gbc);

        gbc.gridy = 8;
        submitButton.addActionListener(this);
        mainPanel.add(submitButton, gbc);

        gbc.gridy = 9;
        mainPanel.add(messageLabel, gbc);

        frame.add(mainPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, String label, JComponent field, int row) {
        gbc.gridy = row;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel(label), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(field, gbc);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            if (!terms.isSelected()) {
                messageLabel.setForeground(Color.red);
                messageLabel.setText("Please agree to the Terms and Conditions");
                return;
            }

            String userID = userIDField.getText();
            String password = new String(passwordField.getPassword());

            idandPasswords.saveUserInfo(userID,
                nameField.getText(), addressField.getText(),
                ageField.getText(), phoneField.getText(),
                emailField.getText(), password);

            messageLabel.setForeground(Color.green);
            messageLabel.setText("Registration Successful!");
            new javax.swing.Timer(2000, evt -> frame.dispose()).start();
        }
    }
}