import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class AccountInfo {
    private JFrame frame = new JFrame("Account Information");

    private JLabel nameLabel = new JLabel();
    private JLabel addressLabel = new JLabel();
    private JLabel ageLabel = new JLabel();
    private JLabel phoneLabel = new JLabel();
    private JLabel emailLabel = new JLabel();
    private JLabel userIDLabel = new JLabel();
    private JLabel passwordLabel = new JLabel();

    private JButton updateButton = new JButton("Update Information");

    public AccountInfo(IDandPasswords idandPasswords, String userID) {
        String[] userInfo = idandPasswords.getUserInfo(userID);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new GridLayout(8, 2));

        frame.add(new JLabel("Name:"));
        nameLabel.setText(userInfo != null ? userInfo[0] : "N/A");
        frame.add(nameLabel);

        frame.add(new JLabel("Address:"));
        addressLabel.setText(userInfo != null ? userInfo[1] : "N/A");
        frame.add(addressLabel);

        frame.add(new JLabel("Age:"));
        ageLabel.setText(userInfo != null ? userInfo[2] : "N/A");
        frame.add(ageLabel);

        frame.add(new JLabel("Phone:"));
        phoneLabel.setText(userInfo != null ? userInfo[3] : "N/A");
        frame.add(phoneLabel);

        frame.add(new JLabel("Email:"));
        emailLabel.setText(userInfo != null ? userInfo[4] : "N/A");
        frame.add(emailLabel);

        frame.add(new JLabel("Username:"));
        frame.add(new JLabel(userID));

        frame.add(new JLabel("Password:"));
        passwordLabel.setText(userInfo != null ? userInfo[5].replaceAll(".", "*") : "N/A");
        frame.add(passwordLabel);

        // Add the Update button
        frame.add(new JLabel()); // Placeholder
        frame.add(updateButton);

        // Add action listener for the Update button
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new UpdateInfo(idandPasswords, userID); // Open UpdateInfo form
                frame.dispose(); // Close the AccountInfo window
            }
        });

        frame.setVisible(true);
    }
}