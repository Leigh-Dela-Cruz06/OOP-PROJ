import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class UpdateInfo implements ActionListener {
    JFrame frame = new JFrame("Update Information");
    JTextField nameField = new JTextField(20);
    JTextField addressField = new JTextField(20);
    JTextField ageField = new JTextField(20);
    JTextField phoneField = new JTextField(20);
    JTextField emailField = new JTextField(20);
    JPasswordField passwordField = new JPasswordField(20);
    JButton updateButton = new JButton("Update");

    IDandPasswords idandPasswords;
    String userID;

    public UpdateInfo(IDandPasswords idandPasswords, String userID) {
        this.idandPasswords = idandPasswords;
        this.userID = userID;

        String[] userInfo = idandPasswords.getUserInfo(userID);

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setLayout(new GridLayout(7, 2));

        frame.add(new JLabel("Name:"));
        nameField.setText(userInfo != null ? userInfo[0] : "");
        frame.add(nameField);

        frame.add(new JLabel("Address:"));
        addressField.setText(userInfo != null ? userInfo[1] : "");
        frame.add(addressField);

        frame.add(new JLabel("Age:"));
        ageField.setText(userInfo != null ? userInfo[2] : "");
        frame.add(ageField);

        frame.add(new JLabel("Phone:"));
        phoneField.setText(userInfo != null ? userInfo[3] : "");
        frame.add(phoneField);

        frame.add(new JLabel("Email:"));
        emailField.setText(userInfo != null ? userInfo[4] : "");
        frame.add(emailField);

        frame.add(new JLabel("Password:"));
        passwordField.setText(userInfo != null ? userInfo[5] : "");
        frame.add(passwordField);

        frame.add(new JLabel()); // Placeholder
        updateButton.addActionListener(this);
        frame.add(updateButton);

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == updateButton) {
            // Collect updated information
            String name = nameField.getText();
            String address = addressField.getText();
            String age = ageField.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            // Save the updated information
            idandPasswords.saveUserInfo(userID, name, address, age, phone, email, password);

            JOptionPane.showMessageDialog(frame, "Information updated successfully!");
            frame.dispose(); // Close the update form

            // Open the updated AccountInfo window
            new AccountInfo(idandPasswords, userID);
        }
    }
}